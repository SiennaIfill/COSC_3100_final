
public class Testing {

	public static void main(String[] args) {
		Deck deck = new Deck();
		System.out.println(deck.PrintDeck());
		deck.Shuffle();
		System.out.println(deck.PrintDeck());
	}

}
